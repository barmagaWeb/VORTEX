---
name: 01-frontend-ui-ux
description: Use when changing page layouts, visual styling, responsive behavior, navigation, forms, dialogs, or interaction design in VORTEX.
---

# Frontend UI/UX Engineering

## Mission
Improve VORTEX's interface without replacing its identity. The project is a React 18 + TypeScript + Vite application with Tailwind CSS, Framer Motion, Lucide icons, bilingual Arabic/English support, RTL/LTR direction, and dark/light themes.

## Inspect first
- Read the target page and its child components under `src/pages/` and `src/components/`.
- Check `src/styles/index.css`, theme/language contexts, shared UI primitives, and existing responsive breakpoints.
- Reuse existing `Button`, `Input`, `Modal`, `Tabs`, `Avatar`, `Badge`, `Skeleton`, and `EmptyState` components where appropriate.
- Identify the page's loading, empty, error, success, and permission-denied states before changing its appearance.

## Rules
- Preserve VORTEX branding, logo, color language, typography, and established visual patterns unless the task explicitly requests a redesign.
- Build mobile-first and verify narrow mobile, tablet, laptop, and wide desktop layouts.
- Support both `dir="rtl"` and `dir="ltr"`; avoid hard-coded left/right assumptions when logical CSS properties can be used.
- Support dark and light themes with readable contrast and visible focus states.
- Every visible control must perform a real action. Do not add decorative buttons, fake counts, fake upgrade flows, or placeholder actions.
- Use Framer Motion only for meaningful, restrained transitions; respect reduced-motion preferences.
- Keep forms understandable: labels, validation, disabled/loading states, and actionable error messages.
- Use skeletons for loading and useful empty states rather than blank panels.

## Verification
- Exercise the same page in Arabic and English, RTL and LTR, dark and light.
- Test keyboard navigation, focus order, modal escape/close behavior, and mobile touch targets.
- Check for overflow, clipped menus, layout shifts, and inaccessible contrast.
- Run `npm run typecheck`, `npm test`, and `npm run build` after changes when dependencies are available.

## Do not
- Replace the design system with a new component library without approval.
- use fixed pixel widths that break small screens.
- claim visual testing was performed unless the UI was actually launched and checked.

