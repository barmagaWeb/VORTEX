---
name: 02-react-architecture
description: Use when adding features, routes, providers, shared components, or restructuring React code.
---

# React Application Architecture

## Mission
Keep VORTEX modular, predictable, and maintainable. It uses React 18, TypeScript, React Router, context providers, domain service interfaces, Supabase implementations, and Mock implementations.

## Inspect first
- Trace the route from the app/router entry point to page, components, context, service interface, and service implementation.
- Review `src/context/`, `src/services/interfaces/`, `src/services/supabase/`, `src/services/mock/`, and `src/types/`.
- Check existing tests and translation keys before adding a new domain.

## Architecture rules
- Keep page components focused on composition and user interaction; move reusable behavior into hooks or domain services when justified.
- Put domain contracts in `src/services/interfaces/`; keep Supabase and Mock implementations behaviorally aligned.
- Keep shared domain types in `src/types/` and avoid duplicating incompatible shapes in components.
- Keep providers limited to cross-cutting state such as authentication, theme, language, and toast notifications.
- Avoid giant components, circular imports, hidden global state, and service calls scattered across presentational components.
- Use React Router conventions already present; protect authenticated/admin routes consistently.
- Do not bypass service interfaces with direct Supabase calls from UI components unless the architecture explicitly requires it.

## Feature workflow
1. Map the current route and dependencies.
2. Define types and service contract.
3. Implement Mock behavior for deterministic development/tests.
4. Implement Supabase behavior.
5. Connect UI and states.
6. Add tests for both success and failure behavior.
7. Update translations and documentation.

## Verification
Check route guards, refresh/deep-link behavior, provider nesting, cleanup of subscriptions/effects, and parity between Mock and Supabase implementations.

