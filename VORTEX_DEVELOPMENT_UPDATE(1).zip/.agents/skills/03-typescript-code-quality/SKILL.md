---
name: 03-typescript-code-quality
description: Use for TypeScript changes, refactoring, type errors, lint-like cleanup, and API contract design.
---

# TypeScript and Code Quality

## Mission
Make the codebase safer and easier to evolve without hiding defects.

## Rules
- Prefer explicit domain types and discriminated unions over `any`, broad casts, or loosely shaped objects.
- Treat API/database values as untrusted input and validate/normalize them at boundaries.
- Use `unknown` for uncertain values, then narrow them safely.
- Avoid non-null assertions unless the invariant is proven and documented.
- Keep DTOs, domain models, and database row types distinct where their fields or semantics differ.
- Handle nullable fields, empty arrays, missing relations, and stale records explicitly.
- Use exhaustive `switch` handling for important unions.
- Keep functions small and name them for domain intent.
- Do not suppress TypeScript errors with `@ts-ignore`, broad `as any`, or disabled compiler checks to make a build pass.

## VORTEX-specific checks
- Preserve consistency with `src/types/index.ts`.
- Keep `IPostService`, `IMessagingService`, `IStoriesService`, `ICommunityService`, and related contracts aligned with both implementations.
- Check Arabic/English translation object key parity when adding UI labels.
- Confirm removed video/Reels concepts are not accidentally reintroduced if current product scope remains image-only.

## Workflow
Inspect compiler settings, understand the actual type error, fix the boundary or model causing it, and add a regression test where practical.

## Verification
Run `npm run typecheck`, `npm test`, and `npm run build`. Report exact command outcomes. A syntax parse is not a successful typecheck.

