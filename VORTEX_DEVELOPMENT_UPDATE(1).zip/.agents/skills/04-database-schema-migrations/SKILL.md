---
name: 04-database-schema-migrations
description: Use when changing Supabase/Postgres schema, relations, indexes, constraints, functions, or migrations.
---

# Database Design and SQL Migrations

## Mission
Design reliable PostgreSQL structures for VORTEX's social graph, posts, comments, reactions, bookmarks, communities, conversations, messages, notifications, moderation, and media metadata.

## Inspect first
- Read every migration in `supabase/migrations/` in filename order before editing.
- Read the matching service queries and TypeScript domain types.
- Inspect existing indexes, foreign keys, check constraints, triggers, RPCs, and RLS policies.
- Read `supabase/tests/` and the integration notes.

## Rules
- Add new changes as ordered, additive migrations. Do not rewrite already-applied migrations without a documented migration strategy.
- Use UUID keys and foreign keys consistently with the existing schema.
- Define deletion behavior deliberately (`CASCADE`, `RESTRICT`, or `SET NULL`); consider audit and retention implications.
- Add indexes for actual query predicates, joins, sort orders, and uniqueness requirements. Avoid speculative indexes.
- Use constraints for invariants that must hold regardless of client behavior.
- Make migrations safe to re-run where feasible and document assumptions.
- For concurrent uniqueness requirements, enforce them at the database level, not only in React.
- Use transactions for multi-step operations and RPCs when atomicity is required.
- Avoid N+1 queries and fetching entire tables to derive counts or latest records.
- Never put service-role credentials in browser code.

## VORTEX areas
Review `profiles`, `posts`, `post_media`, `comments`, reactions, `follows`, `communities`, `community_members`, `conversations`, `conversation_members`, `messages`, `notifications`, `reports`, moderation/audit tables, and user settings as relevant.

## Verification
Apply all migrations to a clean local Supabase database, run schema checks and pgTAP tests, then test representative queries. Do not call a migration successful until PostgreSQL actually applies it.

