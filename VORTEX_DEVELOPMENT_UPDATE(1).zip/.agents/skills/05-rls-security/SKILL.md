---
name: 05-rls-security
description: Use for any database access, privacy, permissions, policies, RPC security, blocking, or role changes.
---

# Supabase RLS and Authorization Security

## Mission
Treat PostgreSQL Row Level Security as the authoritative authorization boundary. Frontend hiding is never security.

## Inspect first
- Read all RLS migrations, helper functions, grants, triggers, and RPC definitions.
- Trace every UI/service operation to the table, view, function, or Storage object it accesses.
- Identify anonymous, authenticated, owner, moderator, and admin behavior separately.

## Rules
- Enable RLS on every user-data table exposed through PostgREST.
- Write explicit policies for each operation: SELECT, INSERT, UPDATE, DELETE.
- Use both `USING` and `WITH CHECK` where needed to constrain existing and resulting rows.
- Never trust a client-supplied `user_id`, `role`, `owner_id`, or membership flag; compare with `auth.uid()` or derive identity server-side.
- Prevent privilege escalation, including self-promotion to admin/moderator.
- Restrict private posts, conversations, bookmarks, notifications, reports, and blocked-user interactions.
- Review `SECURITY DEFINER` functions carefully: fixed `search_path`, narrow grants, explicit authorization, and no unsafe dynamic SQL.
- Check policy recursion and helper-function bypasses.
- Do not expose private records through views, RPCs, counts, error messages, or Realtime events.
- Ensure blocked users cannot interact through alternate routes such as comments, mentions, messages, group membership, or media URLs.

## Mandatory adversarial cases
Test user A, user B, anonymous, moderator, and admin separately. Attempt to read/update/delete another user's records and to forge ownership/role fields.

## Verification
Run Supabase migrations and `supabase test db` on a clean local instance. Add pgTAP coverage for every new policy/RPC. Never equate a passing Mock test with an RLS test.

