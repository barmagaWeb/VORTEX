---
name: 06-auth-identity-sessions
description: Use for sign-up, sign-in, email verification, password reset, session persistence, profiles, and account lifecycle.
---

# Authentication and Session Lifecycle

## Mission
Make account access predictable, secure, and recoverable across refreshes, tabs, devices, and expired sessions.

## Inspect first
- Review `src/context/AuthContext.tsx`, auth pages, `IAuthService`, `SupabaseAuthService`, and `MockAuthService`.
- Inspect Supabase Auth settings, callback URLs, profile creation triggers, and session-related RLS.
- Trace app startup, token refresh, sign-out, and route protection.

## Rules
- Let Supabase Auth manage passwords and tokens; never store plaintext passwords.
- Do not log access tokens, refresh tokens, reset links, or verification codes.
- Handle loading, authenticated, unauthenticated, expired, and network-error states distinctly.
- Avoid race conditions between initial session restoration and auth-state subscriptions.
- Unsubscribe auth listeners and prevent stale async results from overwriting newer state.
- Make email verification and password reset flows resistant to account enumeration where possible.
- Keep profile creation idempotent and recoverable if the Auth user exists but profile creation fails.
- Do not silently create a fake production account through Mock fallback.
- Ensure sign-out clears sensitive in-memory state and navigates safely.
- Use secure redirect allowlists for OAuth/callback flows.

## Verification
Test new signup, existing login, invalid credentials, unverified email, reset, refresh, expired session, offline startup, multi-tab updates, and sign-out. Test with two real accounts in a configured Supabase project.

