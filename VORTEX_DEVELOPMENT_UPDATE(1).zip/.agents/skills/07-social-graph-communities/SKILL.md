---
name: 07-social-graph-communities
description: Use for follows, privacy, blocks, community membership, roles, invites, and member management.
---

# Social Graph and Communities

## Mission
Implement consistent relationships and group/community membership rules across UI, services, database, and notifications.

## Inspect first
- Review `src/pages/communities/`, community detail components, `ICommunityService`, Supabase/Mock community services, profile pages, and follow/block operations.
- Inspect `communities`, `community_members`, `follows`, `user_blocks`, and related policies/RPCs.

## Rules
- Define the state model clearly: public/private community, member/non-member, pending/accepted/rejected if requests exist, owner/moderator/member roles.
- Enforce membership permissions in the database, not only in the UI.
- Prevent duplicate membership and duplicate follow relations with database constraints.
- Make join/leave, invite/approve/remove, and role changes atomic where multiple rows change.
- Do not allow a user to remove the final owner/admin unless ownership transfer or safe closure exists.
- Apply block and private-account rules consistently to profile visibility, feed, comments, messages, and community discovery.
- Keep member counts derived from real membership records or safely maintained counters.
- Avoid fake friend-request semantics if the schema only models follows; clearly distinguish the product behavior.

## Verification
Test owner, moderator, member, non-member, private community, blocked user, duplicate requests, last-admin behavior, and simultaneous join/leave attempts.

