---
name: 08-feed-posts-interactions
description: Use for home feed, post creation/edit/delete, comments, likes, reposts, bookmarks, hashtags, and ranking.
---

# Feed, Posts, and Engagement

## Mission
Make feed behavior correct, privacy-aware, efficient, and resilient under changing content.

## Inspect first
- Review `src/pages/feed/`, `src/components/feed/`, `IPostService`, Supabase and Mock post services, post types, and feed migrations.
- Understand current tabs (`forYou`, `following`, `latest`) and community filtering before changing query behavior.

## Rules
- Keep create/edit/delete and reaction behavior consistent between Mock and Supabase services.
- Enforce ownership and visibility at the database level.
- Use stable ordering with a deterministic tie-breaker such as `(created_at, id)`.
- Prefer cursor/keyset pagination for growing feeds; avoid unbounded table downloads and fragile offset pagination for fast-changing timelines.
- Avoid N+1 profile/comment/reaction queries; select only required fields and use bounded nested relations or RPCs.
- Handle optimistic updates with rollback on failure and prevent double submissions.
- Keep counts consistent; do not trust client-provided counters.
- Preserve bookmarks as private to the owning user.
- Normalize hashtags and mentions safely; do not interpret arbitrary content as executable markup.
- Respect image-only product scope if that remains the current VORTEX requirement.

## Verification
Test each feed tab, empty feed, deleted author/post, private/follower-only visibility, blocked users, duplicate likes, rapid clicks, pagination boundaries, and Realtime refresh behavior.

