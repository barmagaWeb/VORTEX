---
name: 09-messaging-realtime
description: Use for direct/group conversations, message history, attachments, read state, Realtime, Presence, or typing indicators.
---

# Messaging and Realtime Systems

## Mission
Deliver reliable private messaging without leaking conversations or duplicating direct-message threads.

## Inspect first
- Review `src/pages/messaging/`, message components, `IMessagingService`, Supabase and Mock messaging services, message types, and migrations 10 onward.
- Inspect conversation summary RPCs, direct-conversation creation RPC, read-state RPC, membership policies, and Realtime publication setup.

## Rules
- Direct conversation uniqueness must be enforced transactionally in PostgreSQL, not by a client-side lookup alone.
- Verify the current user is a member before fetching, sending, marking read, or subscribing to a conversation.
- Use stable chronological ordering and cursor pagination; do not load unbounded history.
- Treat Realtime as an update channel, not the only source of truth. Recover from disconnects and reconcile state.
- Subscribe only to the active conversation/user scope and always unsubscribe on cleanup.
- Avoid duplicate messages when an insert event and optimistic UI update both arrive.
- Keep attachment objects private and authorize every read through Storage policies.
- Derive sender identity from the authenticated session.
- Group rename/member changes/removal/leave operations must validate group role and lifecycle rules.
- Do not claim encryption, delivery guarantees, typing, Presence, or online state unless actually implemented and tested.

## Verification
Use two or more accounts. Test direct thread races, group membership changes, message insert/read, reconnect, duplicate events, unauthorized subscription, private attachment access, and pagination.

