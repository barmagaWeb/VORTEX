---
name: 10-media-storage
description: Use for avatar, cover, post, story, or message images; Storage buckets, signed URLs, cleanup, and media policies.
---

# Media Uploads and Supabase Storage

## Mission
Keep media uploads safe, private where required, size-bounded, and reliable.

## Inspect first
- Review `src/services/supabase/storage.ts`, media upload call sites, bucket migrations, Storage policies, and image rendering components.
- Confirm the current allowed media scope. The latest project delivery describes image-only posts/stories/message attachments and removal of active Reels/video UI.

## Rules
- Enforce file count, byte size, MIME allowlist, and extension policy at the UI and service boundary.
- Treat browser MIME/signature checks as defense in depth only; clients can bypass them.
- Use private buckets for private content and signed URLs with short, appropriate expiry.
- Store object paths in database records rather than long-lived signed URLs.
- Build object paths from authenticated user identity and validated identifiers; never trust a path supplied by another user.
- RLS/Storage policies must authorize reads against the parent post, story, or conversation.
- Validate ownership for overwrite and delete.
- Handle upload cancellation, retry, orphan cleanup, and failed database insert after successful upload.
- For production-grade image safety, use trusted server-side decoding/re-encoding, metadata stripping, and optional scanning.
- Never make a private bucket public merely to fix broken rendering.

## Verification
Test allowed and rejected formats, oversized files, forged content types, unauthorized reads, expired signed URLs, failed uploads, orphan objects, and deletion behavior.

