---
name: 11-notifications-events
description: Use for notifications, unread counts, database triggers, event fan-out, and notification Realtime.
---

# Notifications and Event Consistency

## Mission
Make notifications accurate, private, deduplicated, and consistent with the action that generated them.

## Inspect first
- Review `src/pages/notifications/`, notification UI, `INotificationService`, Supabase/Mock implementations, notification migrations/triggers, and Realtime subscription code.

## Rules
- Define a canonical event-to-notification mapping for follow, like, comment, reply, repost, mention, community, and message events.
- Avoid notifying a user about their own action unless product requirements explicitly say otherwise.
- Prevent duplicate notifications with database uniqueness/idempotency where feasible.
- Derive actor identity from `auth.uid()` and validate the target relationship/resource.
- Keep notification reads restricted to the recipient.
- Make unread counts accurate and avoid hard-coded badges or fabricated sample counts in production.
- Ensure trigger/RPC failures do not silently corrupt the primary action.
- Batch or debounce UI updates; reconcile from the database after reconnect.
- Provide meaningful notification navigation and handle deleted/hidden target records gracefully.

## Verification
Test each event type, self-action, blocked relationships, duplicate event delivery, mark-one/read-all, unread count after reconnect, and recipient isolation using two accounts.

