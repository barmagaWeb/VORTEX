---
name: 12-search-discovery
description: Use for global search, users/posts/communities/hashtags discovery, trending lists, filters, and ranking.
---

# Search, Explore, and Discovery

## Mission
Build relevant, safe, fast discovery for Arabic and English content.

## Inspect first
- Review `src/pages/explore/`, hashtag page, search components/hooks, existing service methods, translations, and schema indexes.
- Identify whether search currently targets users, posts, hashtags, or communities; do not imply a complete global search if only one entity is searched.

## Rules
- Define search scope, normalization, ranking, filters, and privacy behavior before implementing.
- Support Arabic and English input; consider Arabic normalization carefully without destroying meaningful distinctions.
- Debounce requests, cancel stale requests, and avoid sending every keystroke.
- Enforce visibility, private-account, block, and community membership rules in SQL/RLS.
- Use Postgres full-text search, GIN/trigram indexes, or a dedicated service only when justified by real query needs.
- Use cursor pagination and deterministic ordering.
- Never expose hidden profiles, private posts, private communities, or blocked-user content through search results or suggestions.
- Keep trending metrics explainable and resistant to trivial spam manipulation.

## Verification
Test Arabic/English, diacritics and variants, empty query, punctuation, large result sets, stale request races, private content, blocked users, and pagination.

