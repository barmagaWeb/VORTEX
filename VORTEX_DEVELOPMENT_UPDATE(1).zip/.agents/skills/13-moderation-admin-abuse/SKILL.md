---
name: 13-moderation-admin-abuse
description: Use for reports, blocking, moderation actions, admin dashboard, audit logs, rate limits, and platform abuse controls.
---

# Moderation, Admin, and Abuse Prevention

## Mission
Protect users and platform integrity while ensuring privileged actions are accountable.

## Inspect first
- Review admin pages, report types/services, moderation actions, audit logs, block features, database policies, and role helpers.
- Identify which controls exist in the current code and which are only placeholders.

## Rules
- Never trust a role value or admin flag supplied by the browser.
- Enforce moderator/admin authorization in database policies and RPCs.
- Record sensitive moderation actions with actor, target, action, timestamp, and safe metadata.
- Make report creation private to the reporter and report handling restricted to authorized staff.
- Avoid leaking reporter identity or report details to reported users.
- Add rate limits and abuse controls at a trusted backend boundary; client-side throttling is not security.
- Define appeal/reversal and audit behavior for high-impact actions.
- Avoid destructive moderation without confirmation and clear target context.
- Keep admin UI counts sourced from real queries, not demo constants.
- Include account suspension/deletion and data-retention implications in design reviews.

## Verification
Test normal user, moderator, admin, anonymous, forged role, report privacy, audit-log access, repeated abuse, and privilege revocation.

