---
name: 14-testing-quality-assurance
description: Use for test planning, regression coverage, bug fixes, release gates, and validation claims.
---

# Testing and Quality Assurance

## Mission
Prove behavior with repeatable tests and report limitations honestly.

## Existing project tooling
- Vitest and Testing Library are configured in `package.json`.
- Scripts include `npm test`, `npm run typecheck`, `npm run build`, and `npm run test:rls`.
- `supabase/tests/rls_security.test.sql` contains database-level tests; Mock service tests are not substitutes for RLS tests.

## Test layers
1. Unit tests for pure logic and validation.
2. Component tests for loading/error/empty/success and interactions.
3. Service tests for Supabase/Mock contract parity.
4. Integration tests for auth, Storage, RPCs, and PostgREST.
5. pgTAP/RLS tests for authorization boundaries.
6. E2E tests for critical user journeys on desktop/mobile.

## Rules
- Add regression tests for every fixed defect where practical.
- Test failure paths, not only happy paths.
- Use deterministic fixtures and isolate test data.
- Avoid tests that merely assert implementation details or mock away the behavior being tested.
- Do not weaken type checks or remove failing tests to get a green result.
- Distinguish tests written, tests executed, tests passed, tests skipped, and tests blocked.
- Record exact command and environment limitations.

## Release gate
Do not recommend production release while typecheck, unit tests, build, migrations, RLS tests, and critical account-to-account journeys are failing or unverified.

