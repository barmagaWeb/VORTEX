---
name: 15-performance-accessibility-i18n-operations
description: Use for performance, accessibility, Arabic/English localization, observability, deployment, CI, and production readiness.
---

# Performance, Accessibility, Localization, and Operations

## Mission
Make VORTEX usable, inclusive, observable, and deployable without sacrificing correctness.

## Performance
- Measure before optimizing.
- Avoid unnecessary rerenders, huge bundles, unbounded queries, N+1 requests, and large image payloads.
- Use lazy loading/code splitting for heavy routes where appropriate.
- Prefer appropriately sized responsive images and stable layout dimensions.
- Paginate feed, search, and messages.
- Check subscription cleanup and request cancellation.

## Accessibility
- Use semantic HTML, labels, accessible names, keyboard operation, focus management, and visible focus indicators.
- Ensure dialogs trap/restore focus appropriately.
- Do not communicate status by color alone.
- Respect reduced motion and sufficient contrast.
- Verify controls at keyboard-only and screen-reader-friendly interaction level.

## Localization
- Keep English and Arabic translation keys in parity.
- Do not hard-code user-facing strings in components.
- Support RTL/LTR layout and direction-aware icons/spacing.
- Format dates, numbers, and relative time consistently.
- Check text expansion, mixed Arabic/English content, and truncation.

## Operations
- Keep secrets out of source control and browser bundles; only public anon configuration belongs in VITE variables.
- Add CI checks for install, typecheck, tests, and build.
- Add structured error reporting and privacy-safe logs; never log credentials or private message bodies.
- Configure security headers, HTTPS, allowed origins, backup/restore, and rollback plans.
- Document environment variables, migrations, deploy steps, and recovery procedures.
- Monitor auth failures, API errors, Storage failures, Realtime disconnects, and database performance.

## Verification
Use real measurements and deployment checks. Never claim accessibility, performance, monitoring, backup, or deployment readiness without evidence.

